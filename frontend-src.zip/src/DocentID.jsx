import { useState, useRef, useEffect, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────

const API_BASE = "/api/v1";

const ORGANISMS = {
  Bacteria: [
    { value: "staphylococcus aureus", label: "Staphylococcus aureus" },
    { value: "escherichia coli", label: "Escherichia coli" },
    { value: "nocardia species", label: "Nocardia species" },
    { value: "borrelia burgdorferi", label: "Borrelia burgdorferi" },
    { value: "streptococcus pneumoniae", label: "Streptococcus pneumoniae" },
  ],
  Viruses: [
    { value: "hsv-1", label: "HSV-1" },
    { value: "influenza a", label: "Influenza A" },
    { value: "hiv", label: "HIV" },
    { value: "ebv", label: "EBV" },
  ],
  Fungi: [
    { value: "candida albicans", label: "Candida albicans" },
    { value: "aspergillus fumigatus", label: "Aspergillus fumigatus" },
  ],
  Parasites: [
    { value: "plasmodium falciparum", label: "Plasmodium falciparum (malaria)" },
    { value: "taenia solium", label: "Taenia solium" },
  ],
};

const ALL_ORGANISMS = Object.values(ORGANISMS).flat();

const MODULES = [
  {
    id: "history_taking",
    label: "History Taking",
    icon: "🩺",
    description: "Interview the patient directly — gather a history, review exam findings, order diagnostics and see results to build your clinical picture.",
  },
  {
    id: "differential_diagnosis",
    label: "Differential Diagnosis",
    icon: "🔬",
    description: "Build a systematic differential from the presenting complaint and the patient's history — layered clinical reasoning, step by step.",
  },
  {
    id: "management",
    label: "Management",
    icon: "💊",
    description: "Walk through the management for the patient with infection — stabilisation, empiric therapy, targeted treatment, monitoring, escalation, and discharge.",
  },
  {
    id: "pathophys_epi",
    label: "Pathophys & Epidemiology",
    icon: "🧫",
    description: "Understand WHY this disease presents the way it does — mechanisms, virulence factors, and look-alike challenges.",
  },
];

const PHASES = [
  { id: "information_gathering", label: "History & Exam", icon: "🩺" },
  { id: "differential_diagnosis", label: "Differential Dx", icon: "🔬" },
  { id: "tests_management", label: "Tests & Tx", icon: "💊" },
  { id: "feedback", label: "Review", icon: "✅" },
];

const HOW_IT_WORKS_CONTENT = `docent.ID teaches clinical infectious diseases through active case-based learning.

Rather than presenting information to read, it puts you inside a case. You interview a patient, gather findings, reason through a differential diagnosis, and justify your management plan — guided throughout by Socratic questioning that never gives away the answer.

Each session draws on real cases from the MGH ID Images library and is grounded in Mandell's Principles and Practices of Infectious Diseases. The tutor adapts to your reasoning in real time, probing gaps and reinforcing strong thinking.

Four learning modules let you focus on what matters most: building a clinical history, constructing a differential, working through management, or understanding the underlying pathophysiology and epidemiology.`;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateCaseId() {
  return `case_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function formatMessage(text) {
  if (!text) return "";
  let out = text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  out = out.replace(/\*(.*?)\*/g, "<em>$1</em>");
  out = out.replace(/\n/g, "<br/>");
  return out;
}

// ─── Login Page ───────────────────────────────────────────────────────────────

function LoginPage({ onLogin, darkMode, onToggleDark }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    setTimeout(() => {
      if (username === "admin" && password === "admin") {
        onLogin(username);
      } else {
        setError("Incorrect username or password.");
        setLoading(false);
      }
    }, 400);
  };

  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-0)",
    }}>
      {/* top bar */}
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "14px 24px",
        borderBottom: "0.5px solid var(--border)",
      }}>
        <span style={{ fontSize: 17, fontWeight: 500, color: "var(--text-primary)" }}>docent.ID</span>
        <button
          onClick={onToggleDark}
          style={{
            background: "none",
            border: "0.5px solid var(--border-strong)",
            borderRadius: "var(--radius)",
            padding: "5px 12px",
            cursor: "pointer",
            color: "var(--text-secondary)",
            fontSize: 13,
          }}
        >
          {darkMode ? "☀ Light" : "☾ Dark"}
        </button>
      </div>

      {/* center form */}
      <div style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
      }}>
        <div style={{
          width: "100%",
          maxWidth: 360,
          background: "var(--surface-2)",
          border: "0.5px solid var(--border)",
          borderRadius: 12,
          padding: "32px 28px",
        }}>
          <h2 style={{ fontSize: 20, fontWeight: 500, color: "var(--text-primary)", margin: "0 0 4px" }}>
            Sign in
          </h2>
          <p style={{ fontSize: 13, color: "var(--text-muted)", margin: "0 0 24px" }}>
            Access your docent.ID account
          </p>

          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <label style={{ fontSize: 13, color: "var(--text-secondary)", display: "block", marginBottom: 5 }}>Username</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                autoFocus
                style={{
                  width: "100%",
                  padding: "8px 10px",
                  borderRadius: "var(--radius)",
                  border: "0.5px solid var(--border-strong)",
                  background: "var(--surface-1)",
                  color: "var(--text-primary)",
                  fontSize: 14,
                  boxSizing: "border-box",
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: 13, color: "var(--text-secondary)", display: "block", marginBottom: 5 }}>Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                style={{
                  width: "100%",
                  padding: "8px 10px",
                  borderRadius: "var(--radius)",
                  border: "0.5px solid var(--border-strong)",
                  background: "var(--surface-1)",
                  color: "var(--text-primary)",
                  fontSize: 14,
                  boxSizing: "border-box",
                }}
              />
            </div>
            {error && (
              <div style={{ fontSize: 13, color: "var(--text-danger)", padding: "6px 10px", background: "var(--bg-danger)", borderRadius: "var(--radius)" }}>
                {error}
              </div>
            )}
            <button
              type="submit"
              disabled={loading}
              style={{
                padding: "9px",
                background: loading ? "var(--fill-disabled)" : "var(--fill-accent)",
                color: loading ? "var(--text-disabled)" : "var(--on-accent)",
                border: "none",
                borderRadius: "var(--radius)",
                cursor: loading ? "default" : "pointer",
                fontSize: 14,
                fontWeight: 500,
                marginTop: 4,
              }}
            >
              {loading ? "Signing in…" : "Sign in"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

// ─── Modal ────────────────────────────────────────────────────────────────────

function Modal({ title, children, onClose }) {
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 100,
        background: "rgba(0,0,0,0.45)",
        display: "flex", alignItems: "center", justifyContent: "center",
        padding: 24,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: "var(--surface-2)",
          border: "0.5px solid var(--border)",
          borderRadius: 12,
          padding: "28px 28px 24px",
          maxWidth: 520,
          width: "100%",
          maxHeight: "80vh",
          overflowY: "auto",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
          <h2 style={{ fontSize: 18, fontWeight: 500, color: "var(--text-primary)", margin: 0 }}>{title}</h2>
          <button
            onClick={onClose}
            style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", fontSize: 20, lineHeight: 1, padding: 0, marginLeft: 12 }}
          >
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────────

function AppHeader({ user, onLogout, darkMode, onToggleDark, onShowAbout, onShowHowItWorks }) {
  return (
    <header style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 20px",
      height: 52,
      borderBottom: "0.5px solid var(--border)",
      background: "var(--surface-2)",
      flexShrink: 0,
    }}>
      <span style={{ fontSize: 17, fontWeight: 500, color: "var(--text-primary)" }}>docent.ID</span>

      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <button onClick={onToggleDark} style={headerBtnStyle}>
          {darkMode ? "☀ Light" : "☾ Dark"}
        </button>
        <button onClick={onShowAbout} style={headerBtnStyle}>About</button>
        <button onClick={onShowHowItWorks} style={headerBtnStyle}>How it works</button>
        <button
          onClick={onLogout}
          style={{
            ...headerBtnStyle,
            background: "var(--bg-accent)",
            borderColor: "var(--border-accent)",
            color: "var(--text-accent)",
          }}
        >
          {user ? `${user} · sign out` : "Sign in"}
        </button>
      </div>
    </header>
  );
}

const headerBtnStyle = {
  padding: "5px 12px",
  border: "0.5px solid var(--border-strong)",
  borderRadius: "var(--radius)",
  background: "transparent",
  color: "var(--text-secondary)",
  cursor: "pointer",
  fontSize: 13,
};

// ─── Setup Screen ─────────────────────────────────────────────────────────────

function SetupScreen({ onStart }) {
  const [organism, setOrganism] = useState("");
  const [selectedModules, setSelectedModules] = useState([]);

  const toggleModule = (id) => {
    setSelectedModules(prev =>
      prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]
    );
  };

  const canStart = organism && selectedModules.length > 0;

  return (
    <div style={{
      flex: 1,
      overflowY: "auto",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      padding: "40px 24px 60px",
    }}>
      {/* Pathogen selector */}
      <div style={{ width: "100%", maxWidth: 560 }}>
        <p style={{
          fontSize: 13,
          color: "var(--text-secondary)",
          marginBottom: 8,
          fontWeight: 500,
          letterSpacing: "0.03em",
        }}>
          Choose a pathogen to study
        </p>
        <div style={{
          background: "var(--surface-2)",
          border: "0.5px solid var(--border-strong)",
          borderRadius: 12,
          padding: "20px 20px",
        }}>
          <select
            value={organism}
            onChange={e => { setOrganism(e.target.value); setSelectedModules([]); }}
            style={{
              width: "100%",
              padding: "9px 12px",
              borderRadius: "var(--radius)",
              border: "0.5px solid var(--border-strong)",
              background: "var(--surface-1)",
              color: organism ? "var(--text-primary)" : "var(--text-muted)",
              fontSize: 14,
              cursor: "pointer",
            }}
          >
            <option value="">Select an organism…</option>
            {Object.entries(ORGANISMS).map(([group, items]) => (
              <optgroup key={group} label={group}>
                {items.map(o => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </optgroup>
            ))}
          </select>

          {/* random pick */}
          <button
            onClick={() => {
              const r = ALL_ORGANISMS[Math.floor(Math.random() * ALL_ORGANISMS.length)];
              setOrganism(r.value);
              setSelectedModules([]);
            }}
            style={{
              marginTop: 10,
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "var(--text-muted)",
              fontSize: 12,
              padding: 0,
              textDecoration: "underline",
              textUnderlineOffset: 3,
            }}
          >
            Choose randomly
          </button>
        </div>

        {/* Module selection — appears after organism chosen */}
        {organism && (
          <div style={{ marginTop: 28 }}>
            <p style={{
              fontSize: 13,
              color: "var(--text-secondary)",
              marginBottom: 8,
              fontWeight: 500,
              letterSpacing: "0.03em",
            }}>
              Select one or more modules
            </p>

            {/* Module cards in a 2×2 grid */}
            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gap: 10,
            }}>
              {MODULES.map(mod => {
                const active = selectedModules.includes(mod.id);
                return (
                  <button
                    key={mod.id}
                    onClick={() => toggleModule(mod.id)}
                    style={{
                      textAlign: "left",
                      padding: "14px 16px",
                      background: active ? "var(--bg-accent)" : "var(--surface-2)",
                      border: active ? "1.5px solid var(--border-accent)" : "0.5px solid var(--border-strong)",
                      borderRadius: 10,
                      cursor: "pointer",
                      transition: "all 0.13s",
                    }}
                  >
                    <div style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 7,
                      marginBottom: 6,
                    }}>
                      <span style={{ fontSize: 16 }}>{mod.icon}</span>
                      <span style={{
                        fontSize: 13,
                        fontWeight: 500,
                        color: active ? "var(--text-accent)" : "var(--text-primary)",
                      }}>
                        {mod.label}
                      </span>
                      {active && (
                        <span style={{
                          marginLeft: "auto",
                          width: 16,
                          height: 16,
                          borderRadius: "50%",
                          background: "var(--fill-accent)",
                          color: "var(--on-accent)",
                          fontSize: 10,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          flexShrink: 0,
                        }}>✓</span>
                      )}
                    </div>
                    <p style={{
                      fontSize: 12,
                      color: active ? "var(--text-accent)" : "var(--text-secondary)",
                      margin: 0,
                      lineHeight: 1.5,
                    }}>
                      {mod.description}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Start button */}
            <button
              onClick={() => canStart && onStart(organism, selectedModules)}
              disabled={!canStart}
              style={{
                marginTop: 20,
                width: "100%",
                padding: "11px",
                background: canStart ? "var(--fill-accent)" : "var(--fill-disabled)",
                color: canStart ? "var(--on-accent)" : "var(--text-disabled)",
                border: "none",
                borderRadius: "var(--radius)",
                cursor: canStart ? "pointer" : "default",
                fontSize: 14,
                fontWeight: 500,
                transition: "background 0.13s",
              }}
            >
              {canStart
                ? `Start case — ${ORGANISMS[Object.keys(ORGANISMS).find(g => ORGANISMS[g].find(o => o.value === organism))]?.find(o => o.value === organism)?.label}`
                : "Select a module to continue"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Phase Bar ────────────────────────────────────────────────────────────────

function PhaseBar({ currentPhase, onPhaseChange, caseActive }) {
  return (
    <div style={{
      display: "flex",
      gap: 4,
      padding: "8px 16px",
      borderBottom: "0.5px solid var(--border)",
      background: "var(--surface-1)",
      overflowX: "auto",
      flexShrink: 0,
    }}>
      {PHASES.map((phase, i) => {
        const phaseIndex = PHASES.findIndex(p => p.id === currentPhase);
        const isActive = phase.id === currentPhase;
        const isPast = i < phaseIndex;
        const isFuture = i > phaseIndex;
        return (
          <button
            key={phase.id}
            onClick={() => caseActive && !isFuture && onPhaseChange(phase.id)}
            disabled={!caseActive || isFuture}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              padding: "6px 12px",
              borderRadius: 20,
              border: isActive ? "1.5px solid var(--border-accent)" : "0.5px solid var(--border)",
              background: isActive ? "var(--bg-accent)" : "transparent",
              color: isActive ? "var(--text-accent)" : isPast ? "var(--text-secondary)" : "var(--text-muted)",
              cursor: caseActive && !isFuture ? "pointer" : "default",
              fontSize: 13,
              fontWeight: isActive ? 500 : 400,
              whiteSpace: "nowrap",
              flexShrink: 0,
            }}
          >
            <span>{phase.icon}</span>
            <span>{phase.label}</span>
            {isPast && <span style={{ fontSize: 10 }}>✓</span>}
          </button>
        );
      })}
    </div>
  );
}

// ─── Message Bubble ───────────────────────────────────────────────────────────

function MessageBubble({ msg, onFeedback }) {
  const isUser = msg.role === "user";
  const [feedbackGiven, setFeedbackGiven] = useState(null);
  if (msg.role === "system") return null;

  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      alignItems: isUser ? "flex-end" : "flex-start",
      marginBottom: 16,
    }}>
      <div style={{
        display: "flex",
        alignItems: "flex-start",
        gap: 8,
        maxWidth: "85%",
        flexDirection: isUser ? "row-reverse" : "row",
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: "50%",
          background: isUser ? "var(--bg-accent)" : "var(--surface-1)",
          border: "0.5px solid var(--border)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 13, flexShrink: 0, marginTop: 2,
        }}>
          {isUser ? "👤" : "👨‍⚕️"}
        </div>
        <div style={{
          background: isUser ? "var(--bg-accent)" : "var(--surface-2)",
          border: `0.5px solid ${isUser ? "var(--border-accent)" : "var(--border)"}`,
          borderRadius: isUser ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
          padding: "10px 14px",
          fontSize: 14,
          lineHeight: 1.6,
          color: "var(--text-primary)",
        }}>
          {msg.streaming ? (
            <span>
              {msg.content}
              <span style={{
                display: "inline-block", width: 6, height: 14,
                background: "var(--text-secondary)", marginLeft: 2,
                borderRadius: 1, animation: "blink 1s infinite",
              }} />
            </span>
          ) : (
            <span dangerouslySetInnerHTML={{ __html: formatMessage(msg.content) }} />
          )}
        </div>
      </div>

      {!isUser && !msg.streaming && onFeedback && (
        <div style={{ display: "flex", gap: 4, marginTop: 4, marginLeft: 36 }}>
          {[1, 2, 3, 4, 5].map(r => (
            <button
              key={r}
              onClick={() => { setFeedbackGiven(r); onFeedback(msg, r); }}
              style={{
                background: feedbackGiven === r ? "var(--bg-accent)" : "transparent",
                border: "0.5px solid var(--border)",
                borderRadius: 4,
                padding: "2px 6px",
                fontSize: 11,
                color: feedbackGiven === r ? "var(--text-accent)" : "var(--text-muted)",
                cursor: "pointer",
              }}
            >
              {r}
            </button>
          ))}
          {feedbackGiven && <span style={{ fontSize: 11, color: "var(--text-muted)", alignSelf: "center" }}>Rated</span>}
        </div>
      )}
    </div>
  );
}

// ─── Chat Screen ──────────────────────────────────────────────────────────────

function ChatScreen({ organism, modules, onEndCase }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [caseActive, setCaseActive] = useState(false);
  const [caseId] = useState(generateCaseId);
  const [currentPhase, setCurrentPhase] = useState("information_gathering");
  const [error, setError] = useState(null);
  const [starting, setStarting] = useState(true);

  const historyRef = useRef([]);
  const chatboxRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (chatboxRef.current)
      chatboxRef.current.scrollTop = chatboxRef.current.scrollHeight;
  }, [messages]);

  // Start case on mount
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/start_case`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            organism,
            case_id: caseId,
            model_name: null,
            enable_guidelines: false,
          }),
        });
        if (!res.ok) throw new Error(`Server error ${res.status}`);
        const data = await res.json();
        const msg = { role: "assistant", content: data.initial_message };
        historyRef.current = [msg];
        setMessages([msg]);
        setCaseActive(true);
      } catch (err) {
        setError(`Could not connect to server: ${err.message}`);
      } finally {
        setStarting(false);
        setTimeout(() => inputRef.current?.focus(), 100);
      }
    })();
  }, []);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || loading || !caseActive) return;
    setInput("");
    setError(null);

    const userMsg = { role: "user", content: text };
    historyRef.current = [...historyRef.current, userMsg];
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    const streamingId = Date.now();
    setMessages(prev => [...prev, { id: streamingId, role: "assistant", content: "", streaming: true }]);

    try {
      const res = await fetch(`${API_BASE}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: historyRef.current,
          organism_key: organism,
          case_id: caseId,
          model_name: null,
          feedback_enabled: true,
          current_phase: currentPhase,
        }),
      });
      if (!res.ok) throw new Error(`Server error ${res.status}`);

      const contentType = res.headers.get("content-type") || "";
      let responseText = "";

      if (contentType.includes("text/event-stream")) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          for (const line of decoder.decode(value).split("\n")) {
            if (line.startsWith("data: ") && line.slice(6) !== "[DONE]") {
              try {
                const p = JSON.parse(line.slice(6));
                if (p.content) {
                  responseText += p.content;
                  setMessages(prev => prev.map(m => m.id === streamingId ? { ...m, content: responseText } : m));
                }
                if (p.phase) setCurrentPhase(p.phase);
              } catch {}
            }
          }
        }
      } else {
        const data = await res.json();
        responseText = data.response || data.content || data.message || JSON.stringify(data);
        if (data.phase) setCurrentPhase(data.phase);
      }

      const aMsg = { role: "assistant", content: responseText };
      historyRef.current = [...historyRef.current, aMsg];
      setMessages(prev => prev.map(m => m.id === streamingId ? aMsg : m));
    } catch (err) {
      setMessages(prev => prev.filter(m => m.id !== streamingId));
      setError(`Message failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }, [input, loading, caseActive, organism, caseId, currentPhase]);

  const handleFeedback = useCallback(async (msg, rating) => {
    try {
      await fetch(`${API_BASE}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rating, message: msg.content, history: historyRef.current, case_id: caseId, organism }),
      });
    } catch {}
  }, [caseId, organism]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const orgLabel = Object.values(ORGANISMS).flat().find(o => o.value === organism)?.label || organism;
  const moduleLabels = modules.map(id => MODULES.find(m => m.id === id)?.label).filter(Boolean);

  return (
    <div style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "hidden" }}>
      {/* case context strip */}
      <div style={{
        padding: "6px 16px",
        background: "var(--surface-1)",
        borderBottom: "0.5px solid var(--border)",
        display: "flex",
        alignItems: "center",
        gap: 10,
        flexShrink: 0,
        flexWrap: "wrap",
      }}>
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>
          <em style={{ fontStyle: "italic", color: "var(--text-primary)", fontWeight: 500 }}>{orgLabel}</em>
          {" · "}
          {moduleLabels.join(", ")}
        </span>
        <button
          onClick={onEndCase}
          style={{
            marginLeft: "auto",
            background: "none",
            border: "0.5px solid var(--border)",
            borderRadius: "var(--radius)",
            padding: "3px 10px",
            cursor: "pointer",
            color: "var(--text-muted)",
            fontSize: 12,
          }}
        >
          ← New case
        </button>
      </div>

      <PhaseBar currentPhase={currentPhase} onPhaseChange={setCurrentPhase} caseActive={caseActive} />

      {/* messages */}
      <div ref={chatboxRef} style={{ flex: 1, overflowY: "auto", padding: "20px 16px" }}>
        {starting && (
          <div style={{ color: "var(--text-muted)", fontSize: 14, display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ display: "inline-block", width: 14, height: 14, border: "2px solid var(--border-strong)", borderTopColor: "var(--text-accent)", borderRadius: "50%", animation: "spin 0.7s linear infinite" }} />
            Starting case…
          </div>
        )}
        {messages.map((msg, i) => (
          <MessageBubble
            key={i}
            msg={msg}
            onFeedback={msg.role === "assistant" && !msg.streaming ? handleFeedback : null}
          />
        ))}
        {loading && !messages.find(m => m.streaming) && (
          <div style={{ color: "var(--text-muted)", fontSize: 13, display: "flex", gap: 8, alignItems: "center" }}>
            <span style={{ display: "inline-block", width: 14, height: 14, border: "2px solid var(--border-strong)", borderTopColor: "var(--text-accent)", borderRadius: "50%", animation: "spin 0.7s linear infinite" }} />
            Thinking…
          </div>
        )}
      </div>

      {error && (
        <div style={{
          padding: "8px 16px",
          background: "var(--bg-danger)",
          color: "var(--text-danger)",
          fontSize: 13,
          display: "flex",
          justifyContent: "space-between",
          flexShrink: 0,
        }}>
          {error}
          <button onClick={() => setError(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "inherit" }}>×</button>
        </div>
      )}

      {/* input */}
      <div style={{
        padding: "12px 16px",
        borderTop: "0.5px solid var(--border)",
        background: "var(--surface-2)",
        display: "flex",
        gap: 8,
        alignItems: "flex-end",
        flexShrink: 0,
      }}>
        <textarea
          ref={inputRef}
          value={input}
          onChange={e => {
            setInput(e.target.value);
            e.target.style.height = "auto";
            e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
          }}
          onKeyDown={handleKeyDown}
          placeholder={caseActive ? "Message the tutor…" : "Waiting for case to start…"}
          disabled={!caseActive || loading}
          rows={1}
          style={{
            flex: 1,
            padding: "9px 12px",
            borderRadius: "var(--radius)",
            border: "0.5px solid var(--border-strong)",
            background: caseActive ? "var(--surface-2)" : "var(--surface-1)",
            color: "var(--text-primary)",
            fontSize: 14,
            lineHeight: 1.5,
            fontFamily: "var(--font-sans)",
            outline: "none",
            minHeight: 38,
            maxHeight: 120,
            overflowY: "auto",
            resize: "none",
          }}
        />
        <button
          onClick={sendMessage}
          disabled={!input.trim() || loading || !caseActive}
          style={{
            padding: "8px 16px",
            borderRadius: "var(--radius)",
            border: "0.5px solid var(--border-strong)",
            background: "transparent",
            color: input.trim() && !loading && caseActive ? "var(--text-accent)" : "var(--text-muted)",
            cursor: input.trim() && !loading && caseActive ? "pointer" : "default",
            fontSize: 13,
            fontWeight: 500,
          }}
        >
          Send
        </button>
      </div>
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────

export default function DocentID() {
  const [user, setUser] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [screen, setScreen] = useState("login"); // login | setup | chat
  const [caseOrganism, setCaseOrganism] = useState(null);
  const [caseModules, setCaseModules] = useState([]);
  const [modal, setModal] = useState(null); // null | "about" | "howitworks"

  // Apply dark mode to root
  useEffect(() => {
    document.documentElement.setAttribute("data-mode", darkMode ? "dark" : "light");
  }, [darkMode]);

  const handleLogin = (username) => {
    setUser(username);
    setScreen("setup");
  };

  const handleLogout = () => {
    setUser(null);
    setScreen("login");
    setCaseOrganism(null);
    setCaseModules([]);
  };

  const handleStartCase = (organism, modules) => {
    setCaseOrganism(organism);
    setCaseModules(modules);
    setScreen("chat");
  };

  const handleEndCase = () => {
    setCaseOrganism(null);
    setCaseModules([]);
    setScreen("setup");
  };

  if (screen === "login") {
    return (
      <>
        <style>{globalStyles}</style>
        <LoginPage onLogin={handleLogin} darkMode={darkMode} onToggleDark={() => setDarkMode(d => !d)} />
      </>
    );
  }

  return (
    <>
      <style>{globalStyles}</style>
      <div style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        background: "var(--surface-0)",
        fontFamily: "var(--font-sans)",
        overflow: "hidden",
      }}>
        <AppHeader
          user={user}
          onLogout={handleLogout}
          darkMode={darkMode}
          onToggleDark={() => setDarkMode(d => !d)}
          onShowAbout={() => setModal("about")}
          onShowHowItWorks={() => setModal("howitworks")}
        />

        {screen === "setup" && (
          <SetupScreen onStart={handleStartCase} />
        )}

        {screen === "chat" && caseOrganism && (
          <ChatScreen
            organism={caseOrganism}
            modules={caseModules}
            onEndCase={handleEndCase}
          />
        )}

        {/* Modals */}
        {modal === "about" && (
          <Modal title="About docent.ID" onClose={() => setModal(null)}>
            <p style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.7, margin: 0 }}>
              docent.ID is an AI-powered clinical microbiology tutor built for medical students.
              It uses real cases, Socratic teaching, and evidence-based resources to help learners
              reason through infectious disease — not just recall it.
            </p>
            <p style={{ fontSize: 14, color: "var(--text-muted)", lineHeight: 1.7, margin: "12px 0 0" }}>
              More details coming soon.
            </p>
          </Modal>
        )}

        {modal === "howitworks" && (
          <Modal title="How it works" onClose={() => setModal(null)}>
            {HOW_IT_WORKS_CONTENT.split("\n\n").map((para, i) => (
              <p key={i} style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.7, margin: i === 0 ? 0 : "12px 0 0" }}>
                {para}
              </p>
            ))}
          </Modal>
        )}
      </div>
    </>
  );
}

// ─── Global styles ────────────────────────────────────────────────────────────

const globalStyles = `
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
  @keyframes spin { to { transform: rotate(360deg); } }
  * { box-sizing: border-box; }
  body { margin: 0; }
  textarea { resize: none; }
  select { appearance: auto; }
`;
